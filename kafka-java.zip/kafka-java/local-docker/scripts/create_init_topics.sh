# Set working directory to Kafka /bin
cd /opt/bitnami/kafka/bin

# Create Kafka Topic
./kafka-topics.sh --create --topic krawchukd.default --bootstrap-server localhost:9092

# Create Kafka Retry Topic
./kafka-topics.sh --create --topic krawchukd.default.retry --bootstrap-server localhost:9092

# Create Kafka Backout Topic
./kafka-topics.sh --create --topic krawchukd.default.dlq --bootstrap-server localhost:9092

# Validate Topic Creation
./kafka-topics.sh --describe --topic krawchukd.default --bootstrap-server localhost:9092

