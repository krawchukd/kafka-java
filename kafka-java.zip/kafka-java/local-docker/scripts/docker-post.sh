#! /bin/sh

docker exec local-docker-kafka-1 /usr/local/create_init_topics.sh