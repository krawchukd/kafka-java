package com.krawchukd.kafka.kafkajava.exception;

import com.krawchukd.kafka.kafkajava.model.request.PublishRequest;

public class InvalidKafkaKeyException extends RuntimeException {
    private final PublishRequest request;

    public InvalidKafkaKeyException(PublishRequest request) {
        this.request = request;
    }

    public PublishRequest getRequest() {
        return request;
    }

}
