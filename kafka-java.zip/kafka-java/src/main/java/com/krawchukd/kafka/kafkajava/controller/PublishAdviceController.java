package com.krawchukd.kafka.kafkajava.controller;

import com.krawchukd.kafka.kafkajava.exception.InvalidKafkaKeyException;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.errors.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.support.ErrorMessage;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

@Slf4j
@RestControllerAdvice
public class PublishAdviceController {

    @Value("${kafka.producer.topic.dlq.name}")
    private String defaultTopicDlqName;

    @Autowired
    @Qualifier("DefaultKafkaTemplate")
    private KafkaTemplate<Integer, String> defaultKafkaTemplate;

    @ExceptionHandler(InvalidKafkaKeyException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ErrorMessage invalidKafkaKeyException(InvalidKafkaKeyException ex) {
        ErrorMessage message = new ErrorMessage(ex);

        ListenableFuture<SendResult<Integer, String>> future = defaultKafkaTemplate.send(defaultTopicDlqName, ex.getRequest().getMessage());

        future.addCallback(new ListenableFutureCallback<SendResult<Integer, String>>() {
            @Override
            public void onFailure(Throwable ex1) {
                log.error("Unable to process message to dead letter queue with payload: {}.", ex.getRequest().getMessage());
            }

            @Override
            public void onSuccess(SendResult<Integer, String> result) {
                log.info("Message with detail: {} sent to dead letter queue.", ex.getRequest().getMessage());
            }
        });

        return message;
    }

}
