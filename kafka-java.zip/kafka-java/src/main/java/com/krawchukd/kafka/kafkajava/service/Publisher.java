package com.krawchukd.kafka.kafkajava.service;

import com.krawchukd.kafka.kafkajava.exception.InvalidKafkaKeyException;
import com.krawchukd.kafka.kafkajava.model.request.PublishRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@Slf4j
@Validated
@RestController
@RequestMapping("/publish")
public class Publisher {

    @Value("${kafka.producer.topic.name}")
    private String defaultTopicName;

    @Value("${kafka.producer.topic.retry.name}")
    private String defaultTopicRetryName;

    @Autowired
    @Qualifier("DefaultKafkaTemplate")
    private KafkaTemplate<Integer, String> defaultKafkaTemplate;

    @PostMapping(consumes = {"application/json"}, produces = {"application/json"})
    public void publishMessageToBroker(@RequestBody @Valid PublishRequest publishRequest) {

        if (publishRequest.getKey() == 0) {
            throw new InvalidKafkaKeyException(publishRequest);
        }

        ListenableFuture<SendResult<Integer, String>> future = defaultKafkaTemplate.send(defaultTopicName, publishRequest.getMessage());

        future.addCallback(new ListenableFutureCallback<SendResult<Integer, String>>() {
            @Override
            public void onFailure(Throwable ex) {
                log.error("Error occurred while processing publish request with error: {}. Attempting to place message in backout topic.", ex.getMessage());

                ListenableFuture<SendResult<Integer, String>> future = defaultKafkaTemplate.send(defaultTopicRetryName, publishRequest.getMessage());
            }

            @Override
            public void onSuccess(SendResult<Integer, String> result) {
                log.info("Success sending result: {}", result);
            }
        });
    }
}
