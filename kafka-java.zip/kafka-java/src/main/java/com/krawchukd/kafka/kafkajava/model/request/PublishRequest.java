package com.krawchukd.kafka.kafkajava.model.request;

import com.fasterxml.jackson.annotation.JacksonAnnotation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PublishRequest {

    @NotNull
    private Integer key;
    @NotBlank
    private String message;
    @NotBlank
    private String groupId;

}
