package com.krawchukd.kafka.kafkajava.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

@Slf4j
@Service
public class Listener {

    @Value("${kafka.producer.topic.name}")
    private String defaultTopicName;

    @Value("${kafka.producer.topic.dlq.name}")
    private String defaultTopicDlqName;

    @Autowired
    @Qualifier("DefaultKafkaTemplate")
    private KafkaTemplate<Integer, String> defaultKafkaTemplate;

    @Value("${kafka.producer.topic.retry.name}")
    private String defaultTopicRetryName;

    @Value("${kafka.consumer.groupid}")
    private String groupId;

    @KafkaListener(id = "", topics = "${kafka.producer.topic.retry.name}")
    public void listen(String data) {
        log.info("Reprocessing message with data: {}", data);

        ListenableFuture<SendResult<Integer, String>> future = defaultKafkaTemplate.send(defaultTopicName, data);
        future.addCallback(new ListenableFutureCallback<SendResult<Integer, String>>() {
            @Override
            public void onFailure(Throwable ex) {
                log.error("Failure reprocessing message with data: {} with exception: {}. Sending payload to dlq", data, ex.getMessage());
                defaultKafkaTemplate.send(defaultTopicDlqName, data);
            }

            @Override
            public void onSuccess(SendResult<Integer, String> result) {
                log.info("Message: {} successfully sent to DLQ.", data);
            }
        });
    }

}
